#!/usr/bin/env bash

cd "$(dirname "$0")" || exit 1
. h-manifest.conf

LOG_FILE="${CUSTOM_LOG_BASENAME}.log"
CONF=$(cat "$CUSTOM_CONFIG_FILENAME")

echo "Launching pearl_miner: ./pearl-miner $CONF"
mkdir -p "$(dirname "$LOG_FILE")"
exec > >(tee -a "$LOG_FILE") 2>&1
exec ./pearl-miner $CONF
